-- Execute no SQL Editor do Supabase.
create table if not exists public.quiz_participants (
  id uuid primary key default gen_random_uuid(),
  participant_name text not null check (char_length(participant_name) between 1 and 100),
  course text not null check (char_length(course) between 1 and 100),
  score integer not null check (score between 0 and 6),
  total_questions integer not null default 6 check (total_questions = 6),
  created_at timestamptz not null default now()
);

create table if not exists public.quiz_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.quiz_participants enable row level security;
alter table public.quiz_admins enable row level security;

-- Qualquer pessoa pode enviar o próprio resultado; ninguém pode consultar resultados publicamente.
drop policy if exists "Anyone can submit quiz result" on public.quiz_participants;
create policy "Anyone can submit quiz result" on public.quiz_participants
  for insert to anon, authenticated with check (
    char_length(trim(participant_name)) > 0 and char_length(trim(course)) > 0
    and score between 0 and 6 and total_questions = 6
  );

-- Administradores podem consultar a lista de administradores e resultados.
drop policy if exists "Admins can read admin list" on public.quiz_admins;
create policy "Admins can read admin list" on public.quiz_admins
  for select to authenticated using (user_id = auth.uid());
drop policy if exists "Admins can read participants" on public.quiz_participants;
create policy "Admins can read participants" on public.quiz_participants
  for select to authenticated using (
    exists (select 1 from public.quiz_admins a where a.user_id = auth.uid())
  );

-- Depois de criar seu usuário em Authentication > Users, adicione o UUID dele:
-- insert into public.quiz_admins (user_id) values ('COLE-AQUI-O-UUID-DO-USUARIO');
