import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { LockKeyhole, LogOut, RefreshCw, Users, Trophy, Medal } from "lucide-react";
import { SiteNav } from "@/components/SiteNav";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";

type Participant = { id: string; participant_name: string; course: string; score: number; total_questions: number; created_at: string };
export const Route = createFileRoute("/admin")({ component: Admin });

function Admin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState<string | null>(null);
  const [rows, setRows] = useState<Participant[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [authorized, setAuthorized] = useState(false);

  const load = async () => {
    if (!supabase) return;
    setLoading(true); setError("");
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) { setUser(null); setAuthorized(false); setRows([]); setLoading(false); return; }
    setUser(auth.user.email ?? "Administrador");
    const { data: admin, error: adminError } = await supabase.from("quiz_admins").select("user_id").eq("user_id", auth.user.id).maybeSingle();
    if (adminError || !admin) { setAuthorized(false); setRows([]); setError("Este usuário não tem permissão de administrador. Cadastre o ID dele na tabela quiz_admins."); setLoading(false); return; }
    setAuthorized(true);
    const { data, error: queryError } = await supabase.from("quiz_participants").select("id,participant_name,course,score,total_questions,created_at").order("score", { ascending: false }).order("created_at", { ascending: true });
    if (queryError) setError("Não foi possível carregar os resultados. Confira as políticas de segurança do Supabase.");
    else setRows((data ?? []) as Participant[]);
    setLoading(false);
  };
  useEffect(() => { void load(); }, []);
  const perfect = rows.filter((r) => r.score === r.total_questions).length;
  const ranking = useMemo(() => [...rows].sort((a,b) => b.score-a.score || new Date(a.created_at).getTime()-new Date(b.created_at).getTime()), [rows]);
  const login = async (e: FormEvent) => { e.preventDefault(); if (!supabase) return; setError(""); const { error: loginError } = await supabase.auth.signInWithPassword({ email, password }); if (loginError) setError("E-mail ou senha inválidos."); else await load(); };
  const logout = async () => { await supabase?.auth.signOut(); setUser(null); setAuthorized(false); setRows([]); };

  return <div className="min-h-screen bg-blush text-blush-foreground"><SiteNav /><main className="mx-auto max-w-6xl px-5 py-10">
    <div className="flex flex-wrap items-center justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[0.2em] text-primary">Área restrita</p><h1 className="mt-1 text-3xl font-black">Painel administrativo</h1><p className="mt-1 text-sm text-muted-foreground">Participações e desempenho do quiz Saúde Única.</p></div>{user && <button onClick={logout} className="rounded-full border border-border px-4 py-2 text-sm font-semibold"><LogOut className="mr-2 inline h-4 w-4"/>Sair</button>}</div>
    {!isSupabaseConfigured ? <div className="glass mt-8 p-6">Configure as variáveis VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY para ativar o painel.</div> : !user ? <form onSubmit={login} className="glass mx-auto mt-8 max-w-md p-6"><LockKeyhole className="h-8 w-8 text-primary"/><h2 className="mt-3 text-xl font-bold">Entrar como administrador</h2><label className="mt-5 block text-sm font-bold">E-mail</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} className="mt-2 w-full rounded-xl border border-border bg-white px-4 py-3 text-slate-900 caret-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"/><label className="mt-4 block text-sm font-bold">Senha</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} className="mt-2 w-full rounded-xl border border-border bg-white px-4 py-3 text-slate-900 caret-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"/><button className="glow mt-6 w-full rounded-full bg-gradient-neon py-3 font-bold text-primary-foreground">Entrar</button>{error && <p className="mt-3 text-sm text-destructive">{error}</p>}</form> : !authorized ? <div className="glass mt-8 p-6 text-sm">{error || "Verificando permissão..."}</div> : <>
      <div className="mt-8 grid gap-4 sm:grid-cols-3"><div className="glass p-5"><Users className="h-6 w-6 text-primary"/><p className="mt-3 text-sm text-muted-foreground">Total de participantes</p><p className="text-3xl font-black">{rows.length}</p></div><div className="glass p-5"><Trophy className="h-6 w-6 text-primary"/><p className="mt-3 text-sm text-muted-foreground">Acertaram as 6 questões</p><p className="text-3xl font-black">{perfect}</p></div><div className="glass p-5"><Medal className="h-6 w-6 text-primary"/><p className="mt-3 text-sm text-muted-foreground">Média de acertos</p><p className="text-3xl font-black">{rows.length ? (rows.reduce((s,r)=>s+r.score,0)/rows.length).toFixed(1) : "0,0"}<span className="text-base font-semibold"> / 6</span></p></div></div>
      <div className="mt-8 flex items-center justify-between gap-3"><h2 className="text-xl font-black">Ranking e participantes</h2><button onClick={()=>void load()} className="rounded-full border border-border px-4 py-2 text-sm font-semibold"><RefreshCw className="mr-2 inline h-4 w-4"/>Atualizar</button></div>
      {loading ? <p className="py-8 text-center">Carregando...</p> : <div className="glass mt-4 overflow-x-auto"><table className="w-full min-w-[720px] text-left text-sm"><thead><tr className="border-b border-border text-muted-foreground"><th className="p-4">#</th><th className="p-4">Participante</th><th className="p-4">Curso / turma</th><th className="p-4">Pontuação</th><th className="p-4">Data e hora</th></tr></thead><tbody>{ranking.map((r,index)=><tr key={r.id} className="border-b border-border/60"><td className="p-4 font-bold">{index+1}</td><td className="p-4 font-semibold">{r.participant_name}</td><td className="p-4">{r.course}</td><td className="p-4">{r.score}/{r.total_questions}{r.score===r.total_questions && <span className="ml-2 text-primary">★</span>}</td><td className="p-4">{new Date(r.created_at).toLocaleString("pt-BR")}</td></tr>)}{!ranking.length && <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">Nenhuma participação registrada ainda.</td></tr>}</tbody></table></div>}
      {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
    </>}
  </main></div>;
}
