import { createFileRoute } from "@tanstack/react-router";
import { QRCodeSVG } from "qrcode.react";
import { useEffect, useState } from "react";
import { ArrowRight, Heart, PawPrint, Share2, Users, Leaf, CheckCircle2, Globe2, Home, Lightbulb, Handshake, Instagram } from "lucide-react";
import { SiteNav } from "@/components/SiteNav";
import dogCat from "@/assets/dog-cat-cutout.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Saúde Única — Pessoas, animais e planeta | Refúgio Benjamin" },
      { name: "description", content: "Entenda a Saúde Única, faça o quiz e apoie o Refúgio Benjamin Amor de Patas com PIX." },
      { property: "og:title", content: "Saúde Única — Refúgio Benjamin Amor de Patas" },
      { property: "og:description", content: "Cuidar de pessoas, animais e do planeta é uma só missão." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [quizUrl, setQuizUrl] = useState("/quiz");
  useEffect(() => setQuizUrl(`${window.location.origin}/quiz`), []);

  return (
    <div className="min-h-screen overflow-x-hidden">
      <SiteNav />

      {/* Hero escuro */}
      <section className="relative mx-auto grid max-w-6xl items-end gap-6 px-5 pt-8 md:grid-cols-[1.1fr_1fr_0.9fr]">
        <PawPrint className="absolute left-2 top-4 h-8 w-8 opacity-20" />
        <Heart className="absolute right-6 top-2 h-8 w-8 opacity-40" />
        <div className="pb-10">
          <h1 className="font-display text-5xl font-bold leading-none sm:text-7xl">Saúde <span className="text-accent">Única</span></h1>
          <p className="mt-4 font-display text-2xl leading-snug sm:text-3xl">Cuidar de pessoas, animais e do planeta é uma só missão!</p>
          <div className="squiggle mt-3 w-2/3" />
          <div className="blob mt-6 flex items-center gap-3 bg-card px-6 py-4 text-sm text-card-foreground">
            Porque a saúde de todos está conectada: animais, humanos e meio ambiente.
            <Heart className="h-6 w-6 shrink-0" />
          </div>
        </div>
        <img src={dogCat} alt="Cachorro abraçando um gato" width={1024} height={912} className="relative z-10 mx-auto w-full max-w-md" />
        <div id="sobre" className="blob mb-10 bg-card p-6 text-card-foreground">
          <h2 className="flex items-center gap-2 font-display text-2xl font-bold"><PawPrint className="h-6 w-6" /> Sobre a ONG</h2>
          <p className="mt-3 text-sm"><b className="text-primary">Refúgio Benjamin Amor de Patas</b> é uma ONG dedicada a resgatar, acolher e cuidar de animais em situação de vulnerabilidade, proporcionando amor, abrigo e uma nova chance de vida. ♡</p>
          <a href="#doar" className="glow mt-4 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground">Ajude a ONG <ArrowRight className="h-4 w-4" /></a>
          <a href="https://www.instagram.com/ongrefugiobenjamin.mg/" target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-2 rounded-full border border-primary/30 px-5 py-2.5 text-sm font-bold text-primary transition hover:bg-primary/10">
            <Instagram className="h-4 w-4" /> @ongrefugiobenjamin.mg
          </a>
        </div>
      </section>

      {/* Faixa rosa */}
      <section className="bg-blush text-blush-foreground">
        <div className="mx-auto grid max-w-6xl gap-6 px-5 py-12 lg:grid-cols-[1fr_1.6fr_1fr]">
          <div className="blob bg-card p-6">
            <h2 className="flex items-start gap-2 text-xl font-extrabold text-primary"><PawPrint className="h-6 w-6" /> O que é Saúde Única?</h2>
            <p className="mt-3 text-sm">É a união entre a saúde humana, animal e ambiental. O que acontece com os animais e o meio ambiente também impacta a nossa saúde!</p>
            <div className="relative mx-auto mt-6 h-44 w-52 text-xs font-bold">
              {[{ i: PawPrint, t: "Animais", c: "left-12 top-0" }, { i: Users, t: "Pessoas", c: "left-0 top-16" }, { i: Leaf, t: "Meio Ambiente", c: "left-24 top-16" }].map(({ i: I, t, c }) => (
                <div key={t} className={`absolute ${c} flex h-28 w-28 flex-col items-center justify-center rounded-full border-2 border-primary text-center`}><I className="h-5 w-5" />{t}</div>
              ))}
              <Heart className="absolute left-[5.6rem] top-[5.2rem] h-6 w-6 fill-primary text-primary" />
            </div>
          </div>

          <div className="rounded-[2rem] border-2 border-primary/40 bg-blush p-6">
            <div className="-mt-10 mx-auto flex w-fit items-center gap-3 rounded-full bg-ink px-6 py-3 text-lg font-extrabold text-foreground">
              <Lightbulb className="h-6 w-6" /> Quiz: Teste seus conhecimentos!
            </div>
            <div className="mt-6 grid items-center gap-6 sm:grid-cols-[1fr_auto]">
              <div>
                <p className="text-lg font-bold">Escolha como quer responder ao questionário!</p>
                <p className="mt-2 text-sm text-muted-foreground">Você pode começar pelo botão ou escanear o QR code com a câmera do celular. São 6 perguntas rápidas sobre Saúde Única.</p>
                <a href="/quiz" className="glow mt-5 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 font-bold text-primary-foreground shadow-lg transition hover:scale-[1.02] hover:opacity-90">
                  Responder ao questionário <ArrowRight className="h-5 w-5" />
                </a>
              </div>
              <div className="mx-auto rounded-3xl bg-card p-4 text-center">
                <div className="rounded-2xl bg-blush p-3"><QRCodeSVG value={quizUrl} size={160} bgColor="transparent" fgColor="currentColor" /></div>
                <p className="mt-2 font-display text-lg">Aponte a câmera ♡</p>
              </div>
            </div>
          </div>

          <div className="blob bg-card p-6">
            <h2 className="text-xl font-extrabold text-primary">Por que isso é importante?</h2>
            <ul className="mt-4 space-y-3 text-sm">
              {["Previne doenças (como a raiva, leptospirose e febre maculosa).", "Protege os animais e o meio ambiente.", "Contribui para uma sociedade mais saudável e sustentável."].map((x) => (
                <li key={x} className="flex gap-2"><CheckCircle2 className="h-5 w-5 shrink-0 fill-primary text-card" />{x}</li>
              ))}
            </ul>
            <Globe2 className="mx-auto mt-6 h-20 w-20" strokeWidth={1.2} />
          </div>
        </div>
      </section>

      {/* Como ajudar */}
      <section id="ajudar" className="mx-auto grid max-w-6xl items-center gap-8 px-5 py-12 lg:grid-cols-[auto_1.6fr_1fr_auto]">
        <h2 className="font-display text-4xl leading-tight">Como<br />ajudar? ♡</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:min-w-[30rem]">
          {[{ i: Heart, t: "Doe ração", s: "qualquer quantidade já faz diferença!" }, { i: PawPrint, t: "Contribua com nosso PIX" }, { i: Handshake, t: "Compartilhe nosso trabalho" }, { i: Home, t: "Adote, se puder!" }].map(({ i: I, t, s }) => (
            <div key={t} className="flex min-h-32 flex-col items-center justify-center rounded-3xl bg-card p-4 text-center text-sm font-bold text-card-foreground">
              <I className="mb-2 h-8 w-8" />{t}{s && <span className="text-[11px] font-normal">({s})</span>}
            </div>
          ))}
        </div>
        <p className="font-display text-3xl leading-tight">Juntos, podemos fazer <span className="text-accent">a diferença!</span></p>
        <div id="doar" className="mx-auto rounded-3xl bg-card p-4 text-center text-card-foreground">
          <p className="text-sm font-bold">Doe agora pelo PIX:</p>
          <img src="/pix-refugio-benjamin.png" alt="QR Code PIX oficial do Refúgio Benjamin" loading="lazy" decoding="async" className="mx-auto mt-2 block aspect-square w-40 rounded-xl bg-white object-contain p-1" />
          <p className="mt-2 text-xs font-bold">Refúgio Benjamin<br />Amor de Patas ♡</p>
          <a href="https://www.instagram.com/ongrefugiobenjamin.mg/" target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground transition hover:opacity-90">
            <Instagram className="h-4 w-4" /> Ver Instagram
          </a>
        </div>
      </section>

      <footer className="flex flex-col items-center gap-3 py-8 text-center text-xs opacity-70">
        <a href="https://www.instagram.com/ongrefugiobenjamin.mg/" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-full border border-primary/30 px-5 py-2.5 font-bold text-primary transition hover:bg-primary/10">
          <Instagram className="h-4 w-4" /> Siga @ongrefugiobenjamin.mg
        </a>
        <span><Share2 className="mr-1 inline h-3 w-3" />© {new Date().getFullYear()} Saúde Única · Refúgio Benjamin Amor de Patas</span>
      </footer>
    </div>
  );
}
