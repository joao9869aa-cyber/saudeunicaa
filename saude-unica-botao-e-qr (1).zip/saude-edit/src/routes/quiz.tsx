import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Check, RotateCcw, X, Trophy, Loader2 } from "lucide-react";
import { SiteNav } from "@/components/SiteNav";
import { questions } from "@/data/quiz";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";

export const Route = createFileRoute("/quiz")({
  head: () => ({ meta: [
    { title: "Quiz Saúde Única — Teste seus conhecimentos" },
    { name: "description", content: "Responda ao questionário sobre Saúde Única e descubra quanto você sabe." },
    { property: "og:title", content: "Quiz Saúde Única" },
    { property: "og:description", content: "Teste seus conhecimentos sobre pessoas, animais e meio ambiente." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Quiz,
});

function Quiz() {
  const [participantName, setParticipantName] = useState("");
  const [course, setCourse] = useState("");
  const [started, setStarted] = useState(false);
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<number[]>([]);
  const [confirmed, setConfirmed] = useState(false);
  const [score, setScore] = useState(0);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState("");
  const done = i >= questions.length;
  const q = questions[Math.min(i, questions.length - 1)]!;
  const isCorrect = (sel: number[]) => sel.length === q.answer.length && q.answer.every((a) => sel.includes(a));

  const choose = (k: number) => {
    if (confirmed) return;
    if (q.type === "multi") setPicked((p) => p.includes(k) ? p.filter((x) => x !== k) : [...p, k]);
    else {
      setPicked([k]); setConfirmed(true);
      if (isCorrect([k])) setScore((s) => s + 1);
    }
  };
  const confirmMulti = () => {
    if (!picked.length) return;
    setConfirmed(true);
    if (isCorrect(picked)) setScore((s) => s + 1);
  };
  const finish = async (finalScore: number) => {
    setI(questions.length);
    if (!supabase) { setSaveError("O sistema de registro ainda não foi conectado ao Supabase."); return; }
    setSaving(true); setSaveError("");
    const { error } = await supabase.from("quiz_participants").insert({
      participant_name: participantName.trim(), course: course.trim(), score: finalScore,
      total_questions: questions.length,
    });
    setSaving(false);
    if (error) setSaveError("Não foi possível registrar seu resultado. Avise a organização.");
    else setSaved(true);
  };
  const next = () => {
    if (i + 1 === questions.length) {
      const finalScore = score;
      void finish(finalScore);
    } else { setPicked([]); setConfirmed(false); setI((n) => n + 1); }
  };
  const reset = () => { setI(0); setScore(0); setPicked([]); setConfirmed(false); setSaved(false); setSaveError(""); setStarted(false); };

  return <div className="min-h-screen bg-blush text-blush-foreground"><SiteNav /><main className="mx-auto max-w-2xl px-5 py-12">
    {!started ? <div className="glass p-6 sm:p-8">
      <h1 className="text-2xl font-black sm:text-3xl">Antes de começar!</h1>
      <p className="mt-2 text-muted-foreground">Informe seu nome e curso para registrar sua participação no quiz.</p>
      <label className="mt-6 block text-sm font-bold">Nome</label>
      <input value={participantName} onChange={(e) => setParticipantName(e.target.value)} maxLength={100} className="mt-2 w-full rounded-xl border border-border bg-white px-4 py-3 text-slate-900 caret-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" placeholder="Seu nome" />
      <label className="mt-4 block text-sm font-bold">Curso / turma</label>
      <input value={course} onChange={(e) => setCourse(e.target.value)} maxLength={100} className="mt-2 w-full rounded-xl border border-border bg-white px-4 py-3 text-slate-900 caret-slate-900 placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" placeholder="Ex.: Enfermagem, 2º ano" />
      {!isSupabaseConfigured && <p className="mt-3 text-sm text-destructive">Aviso: o registro online ainda não foi configurado.</p>}
      <button disabled={!participantName.trim() || !course.trim()} onClick={() => setStarted(true)} className="glow mt-6 w-full rounded-full bg-gradient-neon py-3 font-semibold text-primary-foreground disabled:opacity-40">Começar quiz <ArrowRight className="ml-1 inline h-4 w-4" /></button>
      <p className="mt-4 text-xs text-muted-foreground">Seus dados serão usados apenas para contabilizar as participações e os resultados desta atividade.</p>
    </div> : done ? <div className="glass p-8 text-center">
      <Trophy className="mx-auto h-12 w-12 text-primary" /><h1 className="mt-4 text-3xl font-black">Você fez <span className="text-gradient">{score}/{questions.length}</span></h1>
      <p className="mt-3 text-muted-foreground">{score === questions.length ? "Parabéns! Você acertou todas as perguntas!" : score >= Math.ceil(questions.length * 0.8) ? "Incrível! Você é um guardião da Saúde Única." : "Bom começo! Cada aprendizado protege pessoas, animais e o planeta."}</p>
      {saving && <p className="mt-4 text-sm"><Loader2 className="mr-2 inline h-4 w-4 animate-spin" />Registrando seu resultado...</p>}
      {saved && <p className="mt-4 text-sm font-bold text-primary">Participação registrada com sucesso!</p>}
      {saveError && <p className="mt-4 text-sm text-destructive">{saveError}</p>}
      <div className="mt-6 flex flex-wrap justify-center gap-3"><button onClick={reset} className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 font-semibold"><RotateCcw className="h-4 w-4" />Refazer</button><Link to="/" hash="doar" className="glow rounded-full bg-gradient-neon px-5 py-2.5 font-semibold text-primary-foreground">Ajudar a ONG</Link></div>
    </div> : <div className="glass p-6 sm:p-8">
      <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-muted-foreground"><span>Pergunta {i + 1} de {questions.length}</span><span className="text-primary">{score} acertos</span></div>
      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full bg-gradient-neon transition-all" style={{ width: `${((i + (confirmed ? 1 : 0)) / questions.length) * 100}%` }} /></div>
      <h1 className="mt-6 text-xl font-bold sm:text-2xl">{q.q}</h1><div className="mt-6 space-y-3">{q.options.map((o, k) => {
        const isRight = q.answer.includes(k), isPicked = picked.includes(k), showRight = confirmed && isRight, showWrong = confirmed && isPicked && !isRight;
        return <button key={o} onClick={() => choose(k)} className={`flex w-full flex-col rounded-xl border p-4 text-left transition ${showRight ? "border-primary bg-primary/10" : showWrong ? "border-destructive bg-destructive/10" : isPicked ? "border-primary" : "border-border hover:border-primary"}`}><span className="flex w-full items-center justify-between gap-3"><span>{o}</span>{showRight && <Check className="h-5 w-5 shrink-0 text-primary" />}{showWrong && <X className="h-5 w-5 shrink-0 text-destructive" />}</span>{confirmed && (isPicked || isRight) && <span className="mt-2 text-sm text-muted-foreground">{q.explain[k]}</span>}</button>;
      })}</div>
      {q.type === "multi" && !confirmed && <button onClick={confirmMulti} disabled={!picked.length} className="glow mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-neon py-3 font-semibold text-primary-foreground disabled:opacity-40">Confirmar resposta</button>}
      {confirmed && <button onClick={next} className="glow mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-neon py-3 font-semibold text-primary-foreground">{i + 1 === questions.length ? "Ver resultado" : "Próxima pergunta"} <ArrowRight className="h-4 w-4" /></button>}
    </div>}
  </main></div>;
}
