import { Link } from "@tanstack/react-router";
import { Heart, PawPrint } from "lucide-react";

export function SiteNav() {
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-3">
        <Link to="/" className="flex items-center gap-2 text-lg font-extrabold tracking-wide sm:text-2xl">
          <PawPrint className="h-6 w-6" /> SAÚDE <span className="text-accent">ÚNICA</span> <PawPrint className="hidden h-6 w-6 sm:block" />
        </Link>
        <nav className="hidden items-center gap-6 text-sm md:flex">
          <Link to="/" activeOptions={{ exact: true }} activeProps={{ className: "border-b-2 border-accent" }} className="pb-1">Início</Link>
          <a href="/#sobre" className="pb-1">Sobre</a>
          <Link to="/quiz" activeProps={{ className: "border-b-2 border-accent" }} className="pb-1">Quiz</Link>
          <a href="/#ajudar" className="pb-1">Como Ajudar</a>
          <a href="/#doar" className="pb-1">ONG</a>
        </nav>
        <a href="/#doar" className="flex items-center gap-2 rounded-full bg-card px-4 py-2 text-xs font-bold text-card-foreground sm:text-sm">
          <Heart className="h-4 w-4 fill-primary text-primary" /> Faça a diferença!
        </a>
      </div>
    </header>
  );
}
