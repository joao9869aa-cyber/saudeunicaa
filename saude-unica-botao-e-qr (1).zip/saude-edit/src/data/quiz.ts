export type QuizQuestion = {
  q: string;
  type: "single" | "multi" | "tf";
  options: string[];
  answer: number[];
  explain: string[];
};

export const questions: QuizQuestion[] = [
  {
    q: "O que significa Saúde Única?",
    type: "single",
    options: [
      "Conectar a saúde humana, animal e ambiental.",
      "Cuidar apenas da saúde das pessoas.",
      "Proteger somente a natureza.",
      "Cuidar somente da saúde dos animais.",
    ],
    answer: [0],
    explain: [
      "Saúde Única considera que essas três áreas estão interligadas.",
      "A Saúde Única vai além das pessoas: inclui animais e meio ambiente.",
      "A natureza é só uma das três áreas conectadas pela Saúde Única.",
      "Os animais são só uma das três áreas conectadas pela Saúde Única.",
    ],
  },
  {
    q: "Por que o abandono de animais é também um problema de saúde pública?",
    type: "single",
    options: [
      "Porque não interfere na vida das pessoas.",
      "Porque aumenta a quantidade de animais domésticos nas casas.",
      "Porque pode favorecer doenças, acidentes e desequilíbrios ambientais.",
      "Porque prejudica somente os animais.",
    ],
    answer: [2],
    explain: [
      "O abandono interfere sim na vida das pessoas e da comunidade.",
      "O abandono não significa adoção responsável ou cuidado adequado.",
      "O abandono pode aumentar riscos sanitários e afetar toda a comunidade.",
      "O abandono prejudica os animais, as pessoas e o meio ambiente.",
    ],
  },
  {
    q: "Um animal abandonado pode transmitir doenças para as pessoas?",
    type: "single",
    options: [
      "Somente animais que vivem na natureza transmitem doenças.",
      "Não, animais abandonados não transmitem doenças.",
      "Sim, algumas doenças podem ser transmitidas entre animais e pessoas.",
      "Somente gatos podem transmitir doenças.",
    ],
    answer: [2],
    explain: [
      "Animais domésticos e abandonados também podem transmitir doenças.",
      "Animais abandonados podem, sim, transmitir doenças.",
      "Zoonoses como raiva e leptospirose podem representar riscos à saúde humana.",
      "Cães e outros animais também podem transmitir doenças.",
    ],
  },
  {
    q: "Qual atitude demonstra responsabilidade ao decidir ter um animal de estimação?",
    type: "single",
    options: [
      "Deixar o animal solto nas ruas para passear.",
      "Oferecer alimentação, abrigo, vacinação e cuidados durante toda a vida.",
      "Abandonar quando não puder mais cuidar.",
      "Adotar por impulso, sem pensar no futuro.",
    ],
    answer: [1],
    explain: [
      "Circular sem supervisão pode expor o animal e outras pessoas a riscos.",
      "A guarda responsável envolve atender às necessidades do animal continuamente.",
      "O abandono é crime e coloca o animal e a comunidade em risco.",
      "Adotar exige planejamento e compromisso com toda a vida do animal.",
    ],
  },
  {
    q: "Quais atitudes ajudam a combater o abandono animal e promover a Saúde Única? Selecione todas as corretas.",
    type: "multi",
    options: [
      "Apoiar ONGs e projetos de proteção animal.",
      "Incentivar a adoção responsável.",
      "Promover vacinação, higiene e cuidados veterinários.",
      "Abandonar animais quando eles ficam doentes ou idosos.",
    ],
    answer: [0, 1, 2],
    explain: [
      "O apoio fortalece o acolhimento e o cuidado de animais vulneráveis.",
      "A adoção responsável oferece uma oportunidade de vida com cuidado e proteção.",
      "Essas medidas ajudam a prevenir doenças e proteger a saúde coletiva.",
      "Animais idosos ou doentes precisam ainda mais de cuidados e proteção.",
    ],
  },
  {
    q: "O abandono animal pode prejudicar o equilíbrio ambiental e a saúde da comunidade.",
    type: "tf",
    options: ["Verdadeiro", "Falso"],
    answer: [0],
    explain: [
      "O abandono desequilibra o ambiente e aumenta riscos para toda a comunidade.",
      "O abandono prejudica sim o ambiente e a saúde de todos.",
    ],
  },
];
