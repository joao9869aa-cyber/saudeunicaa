# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Registro de participantes e painel administrativo

1. Crie um projeto no Supabase e abra o SQL Editor.
2. Execute o arquivo `supabase/setup.sql`.
3. Em Authentication > Users, crie o usuário administrador e copie o UUID.
4. Execute no SQL Editor: `insert into public.quiz_admins (user_id) values ('UUID-DO-ADMIN');`.
5. Copie `.env.example` para `.env` e preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` com os dados de Project Settings > API.
6. Instale as dependências (`npm install`) e rode `npm run dev`.
7. No Vercel, configure as mesmas duas variáveis de ambiente e faça um novo deploy.
8. O painel fica em `/admin`.

Use somente a chave pública anon/publishable no frontend. Nunca coloque a `service_role` ou qualquer segredo no código do site. A tabela de resultados não permite leitura pública; apenas usuários listados em `quiz_admins` conseguem ver o painel.
